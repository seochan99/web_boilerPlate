import React from "react";

function MainCard() {
  return <>MainCard</>;
}

export default MainCard;
