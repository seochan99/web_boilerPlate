import React from "react";

function MainSearch() {
  return <>MainSearch</>;
}

export default MainSearch;
