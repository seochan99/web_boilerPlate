import React from "react";
import * as S from "./style";
import Banner from "./banner";

function MainBannerList() {
  return (
    <>
      <Banner />
    </>
  );
}

export default MainBannerList;
