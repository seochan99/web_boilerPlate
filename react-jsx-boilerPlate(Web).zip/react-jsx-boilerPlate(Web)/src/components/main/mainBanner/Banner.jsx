import React from "react";
import * as S from "./style";

function Banner() {
  return (
    <S.BannerWrapper>
      <>banner1</>
    </S.BannerWrapper>
  );
}

export default Banner;
