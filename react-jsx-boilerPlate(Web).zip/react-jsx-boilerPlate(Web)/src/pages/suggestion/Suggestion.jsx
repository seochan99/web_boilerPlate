import React from "react";

function Suggestion() {
  return <>suggestion</>;
}

export default Suggestion;
